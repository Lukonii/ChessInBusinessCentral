var board
var gameVar = new Chess()
var config = {
    draggable: true,
    position: '',
    sparePieces: false,
    onChange: onChange,
    onDragStart: onDragStart,
    onDrop: onDrop,
    onSnapEnd: onSnapEnd
}
var $status = $('#status')
var $fen = $('#fen')
var $pgn = $('#pgn')

function onDragStart (source, piece, position, orientation) {
  // do not pick up pieces if the gameVar is over
  if (gameVar.game_over()) return false

  // only pick up pieces for the side to move
  if ((gameVar.turn() === 'w' && piece.search(/^b/) !== -1) ||
      (gameVar.turn() === 'b' && piece.search(/^w/) !== -1)) {
    return false
  }
}
function makeRandomMove () {
    var possibleMoves = gameVar.moves()
  
    // gameVar over
    if (possibleMoves.length === 0) return
  
    var randomIdx = Math.floor(Math.random() * possibleMoves.length)
    gameVar.move(possibleMoves[randomIdx])
    board.position(gameVar.fen())
}
function onDrop (source, target) {
  // see if the move is legal
  var move = gameVar.move({
    from: source,
    to: target,
    promotion: 'q' // NOTE: always promote to a queen for example simplicity
  })

  // illegal move
  if (move === null) return 'snapback'
  // make random legal move for black
  window.setTimeout(makeRandomMove, 250)
  updateStatus()
}

// update the board position after the piece snap
// for castling, en passant, pawn promotion
function onSnapEnd () {
  board.position(gameVar.fen())
}

function updateStatus () {
  var status = ''

  var moveColor = 'White'
  if (gameVar.turn() === 'b') {
    moveColor = 'Black'
  }

  // checkmate?
  if (gameVar.in_checkmate()) {
    status = 'Game over, ' + moveColor + ' is in checkmate.'
  }

  // draw?
  else if (gameVar.in_draw()) {
    status = 'Game over, drawn position'
  }

  // gameVar still on
  else {
    status = moveColor + ' to move'

    // check?
    if (gameVar.in_check()) {
      status += ', ' + moveColor + ' is in check'
    }
  }

  $status.html(status)
  $fen.html(gameVar.fen())
  $pgn.html(gameVar.pgn())
}
function StartGame()
{
    /*gameVar = null;
    gameVar = new Chess();
    board = null;
    board = Chessboard('board10', config);
    board.start();*/
    gameVar.reset();
    board.start();
}
function ClearGame()
{
    board.clear();
}
function UpdateTable(oldPos,newPos)
{   
    var base = "8/8/8/8/8/8/8/8";
    if (oldPos !== base) {
        Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("UpdateTable",[oldPos,newPos]);
    }
}
function onChange (oldPos, newPos) {
    var o,n;
    o = Chessboard.objToFen(oldPos);
    n = Chessboard.objToFen(newPos);
    UpdateTable(o,n)
}
function LoadGame(newPos)
{
    /*var configNew = {
        draggable: true,
        position: newPos,
        sparePieces: false,
        onChange: onChange,
        onDragStart: onDragStart,
        onDrop: onDrop,
        onSnapEnd: onSnapEnd
    }*/
    gameVar.reset();
    gameVar.load(newPos+' w - - 1 45');
    board.position(newPos);
    //board = Chessboard('board10', configNew);
}
function Render()
{
    HTMLContainer.insertAdjacentHTML('beforeend','<div id="board10" style="width: 500px"></div>');
    board = Chessboard('board10', config)
    StartGame();
    //updateStatus();
}

